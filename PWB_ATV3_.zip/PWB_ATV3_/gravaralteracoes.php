<?php
	include "conexao_mysql.php";
	
	session_start();

	$nomeremedio=$_POST["nome"];
	$farmrespremedio=$_POST["farmresp"];
	$validaderemedio=$_POST["validade"];
	$tiporemedio=$_POST["tipo"];
	$descricaoremedio=$_POST["descricao"];
	$fotoremedio=$_POST["foto"];
	$usuariologado= $_SESSION['email'];
	
	$sql = mysqli_query($conexao, "UPDATE remedios SET nome='$nomeremedio', farmresp='$farmrespremedio', validade='$validaderemedio', tipo='$tiporemedio', descricao='$descricaoremedio', foto='$fotoremedio', email='$usuariologado') WHERE nome='$nomeremedio'");
	
	if(mysqli_num_rows($logar_sql) == 1){
		echo '<script language="JavaScript" charset="utf-8">alert("Medicamento alterado!")</script>';
		echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=listarMedicamento.php">';
		exit();
	}
	
	echo '<script language="JavaScript" charset="utf-8">alert("Medicamento não foi alterado alterado!")</script>';
	echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=listarMedicamento.php">';
	exit();
?>