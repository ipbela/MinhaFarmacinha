<?php

include('protect.php');

?>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleTESTE.css">
    <link rel="stylesheet" href="style.css">
    
    <title>Menu</title>
</head>
<body onload="initClock()">

<div class="datetime">
	 <div class="date">  
      <span id="dayname">Day</span>,
      <span id="month">Month</span>
      <span id="daynum">00</span>,
      <span id="year">Year</span>
    </div>
    <div class="time">
      <span id="hour">00</span>:
      <span id="minutes">00</span>:
      <span id="seconds">00</span>
      <span id="period">AM</span>
    </div>
   </div>
   <!--digital clock end-->

   <script type="text/javascript">
   	function updateClock(){
       var now = new Date();
       var dname = now.getDay(),
           mo = now.getMonth(),
           dnum = now.getDate(),
           yr = now.getFullYear(),
           hou = now.getHours(),
           min = now.getMinutes(),
           sec = now.getSeconds(),	
           pe = "AM";

           if(hou == 0){
           	hou = 12
           }
           if(hou > 12){
           	hou = hou - 12;
           	pe = "PM";
           }

           Number.prototype.pad = function(digits){
             for(var n = this.toString(); n.length < digits; n = 0 + n);
             return n;
           }

           var months = ["January", "February", "March", "April", "May", "June", "July", "Augest", "September", "October", "November", "december"];

           var week = ["Sunday", "Monday", "Tuesday", "Wednesday", "Turnesday", "Friday", "Saturday"];

           var ids = ["dayname", "month", "daynum", "year", "hour", "minutes", "seconds", "period"];

           var values = [week[dname], months[mo], dnum.pad(2), yr, hou.pad(2), min.pad(2), sec.pad(2), pe];
           for(var i = 0;  i < ids.length; i++)
           document.getElementById(ids[i]).firstChild.nodeValue = values[i];
   	}
   	
   	function initClock(){
   	  updateClock();
   	  window.setInterval("updateClock()", 1);
   	}
   </script>

    <div class="container theme-showcase" role="main">
    <?php
	    setlocale(LC_TIME, 'pt_BR', 'pt_BR.UTF-8', 'pt_BR.UTF-8', 'portuguese');
	    date_default_timezone_set('America/Sao_Paulo');
            $data = date('Y-m-d');
            $hora = date('H');
	            if (($hora >= 0) AND ($hora < 6)) {
                    $mensagem = "Boa madrugada";
	            }else if (($hora >= 6) AND ($hora < 12)) {
                    $mensagem = "Bom dia";
	            }else if (($hora >= 12) AND ($hora < 18)) {
                    $mensagem = "Boa tarde";
	            }else {
                    $mensagem = "Boa noite";
	            }

                if (!isset($_SESSION))
		        session_start();
                $nomeusuario=$_SESSION['nome'];

	        echo '<div class="page">';
	        echo "<h1>".$mensagem.", ".$nomeusuario."</h1><p>";
	        echo strftime("<h5>Hoje é %A, %d de %B de %Y </h5>",strtotime($data)); ?>

    </div>
</div>

<ul>
        <li><a href="#"><ion-icon name="home-outline"></ion-icon></a></li>
        <li class="active"><a href="formMedicamento.php"><ion-icon name="add-circle-outline"></ion-icon></a></li>
        <li><a href="listarMedicamento.php"><ion-icon name="menu-outline"></ion-icon></a></li>
        <li><a href="logout.php"><ion-icon name="log-out-outline"></ion-icon></a></li>
        <div id="marker"></div>
    </ul>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <script>
        let marker = document.querySelector('#marker');
        let list = document.querySelectorAll('ul li');

        function moveIndicator(e){
            marker.style.left = e.offsetLeft+'px';
            marker.style.width = e.offsetWidth+'px';
        }

        list.forEach(link => {
            link.addEventListener('mousemove', (e) => {
                moveIndicator(e.target);
            })
        })

        //add active class in hovered list item
        function activeLink(){
            list.forEach((item) =>
            item .classList.remove('active'))
            this .classList.add('active');
        }

        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

  
</body>
</html>