<?php

$codigo = $_POST['codigo'];
$nome = $_POST['nome'];
$farmresp = $_POST['farmresp'];
$validade  = $_POST['validade'];
$tipo = $_POST['tipo'];
$descricao = $_POST['descricao'];
$foto = $_POST['foto'];

if(!isset($_SESSION)){
session_start();
$usuariologado=$_SESSION["email"] ;

include "conexao_mysql.php";

    $query = mysqli_query($conexao, "INSERT INTO remedios(codigo,nome,farmresp,validade,tipo,descricao,foto,email) VALUES 
    ('$codigo','$nome','$farmresp','$validade','$tipo','$descricao','$foto','$usuariologado')");
    echo '<script language="JavaScript" charset="utf-8">alert("Remédio Cadastrado com Sucesso!!!")</script>';   

    include "formMedicamento.php";

}

else {
    echo "Houveram erros na digitação dos dados";
}

?>