<?php

    include "conexao_mysql.php";
	session_start();
	$usuariologado=$_SESSION['email'];
	
	$nomeremedio=$_POST["nome"];
	$query2 = mysqli_query($conexao,"SELECT * FROM remedios WHERE nome='$nomeremedio' and email='$usuariologado'"); 
	$numm_rows = mysqli_num_rows($query2);
		
	if(mysqli_num_rows($query2) == 0){ //se nenhuma linha foi afetada, informar que nenhum medicamento foi encontrado e voltar
		echo '<script language="JavaScript" charset="utf-8">alert("Medicamento não econtrado!")</script>';
		echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=listarMedicamento.php">';
		exit();
	}
	
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastrostyle.css">

    <title>Altera Remédio</title>
</head>
<body>

    <div id="form">
        <form action="gravaralteracoes.php" method="POST">

        <h1>Alterar Medicamento</h1>

        <?php 
		    while($numm_rows = mysqli_fetch_array($query2)){
		?>

    <!-- Nome do medicamento, farmácia responsável, data de validade, tipo, descrição e foto -->
    <label for="name">Nome</label>
    <div class="input">
        <input id="name" name="nome" placeholder="Insira o nome do medicamento" type="text" value="<?php $numm_rows['nome'];?>">
    </div>

    <label for="farmresp">Farmácia Responsável</label>
    <div class="input">
        <input id="farm" name="farmresp" placeholder="Insira a farmácia responsável" type="text" value="<?php $numm_rows['farmresp'];?>">
    </div>

    <label for="validade">Data de Validade</label>
    <div class="input">
        <input id="validade" name="validade" placeholder="Insira a data de validade" type="date" value="<?php $numm_rows['validade'];?>">
    </div>
    
    <label for="tipo">Tipo</label>
    <div class="input">
        <input id="tipo" name="tipo" placeholder="Insira o tipo" type="text" value="<?php $numm_rows['tipo'];?>">
    </div>

    <label for="descricao">Descrição</label>
    <div class="input">
        <input id="descricao" name="descricao" placeholder="Insira a descrição" type="text" value="<?php $numm_rows['descricao'];?>">
    </div>

    <label for="foto">Foto do Medicamento</label>
    <div class="input">
        <input id="foto" name="foto" type="file" value="<?php $numm_rows['foto'];}?>">
    </div>

    <div id="btn">
        <button type="submit">Alterar</button>
    </div>

    <div id="btn">
        <a href="menu.php">Voltar Ao Menu</a>
    </div>

    </form>
    </div>

</body>
</html>