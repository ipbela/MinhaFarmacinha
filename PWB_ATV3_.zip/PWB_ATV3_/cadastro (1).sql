-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15-Nov-2021 às 15:55
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cadastro`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `remedios`
--

CREATE TABLE `remedios` (
  `nome` varchar(50) DEFAULT NULL,
  `farmresp` varchar(50) DEFAULT NULL,
  `validade` date DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `foto` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `remedios`
--

INSERT INTO `remedios` (`nome`, `farmresp`, `validade`, `tipo`, `descricao`, `foto`, `email`) VALUES
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Dipirona', 'Pharmacy', '2021-12-29', 'bbbbbbbbbb', 'aaaaaaaaaaa', '', NULL),
('Advil', 'Ultrafarma', '2021-11-18', 'Advil', 'hhhhhhh', '', 'sa@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `telefone` varchar(50) DEFAULT NULL,
  `senha` varchar(35) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`telefone`, `senha`, `nome`, `email`, `foto`) VALUES
('123456789', '202020', 'Ana', 'ana@gmail.com', 'barbie.jpg'),
('230230230', 'MTcxMDIwMDQ=', 'Isa', 'isa@gmail.com', 'barbie.jpg'),
('12345678', 'MTIzNDU2', 'Sabrina', 'sa@gmail.com', 'barbie.jpg'),
('30303030', 'MjAyMDIw', 'teste2', 'teste2@gmail.com', 'barbie.jpg'),
('123456789', 'MTIzNDU2', 'teste1', 'teste@gmail.com', 'barbie.jpg');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `remedios`
--
ALTER TABLE `remedios`
  ADD KEY `fk_email` (`email`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`email`);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `remedios`
--
ALTER TABLE `remedios`
  ADD CONSTRAINT `fk_email` FOREIGN KEY (`email`) REFERENCES `usuario` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
