<?php
include "conexao_mysql.php";



if(isset($_POST['email']) || isset($_POST['senha'])) {



if(strlen($_POST['email']) == 0) {
echo "Preencha seu e-mail";
} else if(strlen($_POST['senha']) == 0) {
echo "Preencha sua senha";
} else {



$email = $conexao->real_escape_string($_POST['email']);
$senha = $conexao->real_escape_string($_POST['senha']);



$sql_code = "SELECT * FROM usuario WHERE email = '$email' AND from_base64(senha) = '$senha'";
$sql_query = $conexao->query($sql_code) or die("Falha na execução do código SQL: " . $conexao->error);



$quantidade = $sql_query->num_rows;



if($quantidade == 1) {

$usuario = $sql_query->fetch_assoc();



if(!isset($_SESSION)) {
session_start();

$_SESSION["email"] = $_POST["email"];
$_SESSION["nome"] = $usuario["nome"];
header ("Location: menu.php");

}




} else {
echo "Falha ao logar! Nome ou senha incorretos";
}

}



}
?>