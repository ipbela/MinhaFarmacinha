<html>
	<head>
		<title>Minha Farmacinha</title>
		<meta charset="UTF-8"/>
		<link rel="stylesheet" href="farmacinha.css">
		<script src="https://kit.fontawesome.com/1ab94d0eba.js" crossorigin="anonymous"></script>
	</head>
	<body>

			
		<h1 class="azul">Minha Farmacinha</h1>
		<h2 class="claro">Farmácia On-line</h2>
		<h5 class="contexto"> Registre seu remédio sem sair de casa!
				<br>
				Acesse nosso e-mail: www.farmacinha.com.br
		</h5>
			
		<a href="QuemSomos.html"><button type="button" class="botao">Leia Mais</button></a>
		
		<img src="imagens/mao.png" class="mao" width="120" height="80"/>
		
		<div class="teste">
		<img class="logo" src="imagens/farmacia.png" width="520" height="420"/>	
		<img class="ca" src="imagens/ca.png" width="65" height="65"/>	
		</div>

		<p class="rodape">Política de privacidade | © 2021. Todos os direitos reservados.</p>

		<header>
			<nav>
				<a class="logoo" href="MinhaFarmacinha.html">Minha Farmacinha</a>
				<ul class="nav-list">
					<li><a href="QuemSomos.html">Quem somos</a></li>
					<li><a href="dicasparacomprasonline.html">Dicas para compras On-line</a></li>
					<li><a href="form1.html">Cadastre-se</a></li>
					<li><a href="formulariostyle.html">Login</a></li>
				</ul>
			</nav>
		</header>

	</body>
</html>

<?php
    $caminhoarquivo = fopen("contador.txt", "r+");
    $lerarquivo = fread($caminhoarquivo, 10);
    $contador = $lerarquivo + 1;
    echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<center>Você é o visitante número: $contador </center>";
    fseek($caminhoarquivo, 0);
    fwrite($caminhoarquivo, $contador);
    fclose($caminhoarquivo);
?>
