<html><meta charset="UTF-8"></html>
<?php

include "conexao_mysql.php";

    session_start();

	$usuariologado=$_SESSION['email'];

	$verificausuariologado=mysqli_query($conexao,"select * from remedios where email='$usuariologado'");

	$guardacampo=mysqli_fetch_assoc($verificausuariologado);

    while($dados = mysqli_fetch_assoc($verificausuariologado)){

        $codigoremedio = $dados['codigo'];
        $nomeremedio = $dados['nome'];
        $farmrespremedio = $dados['farmresp'];
        $validaderemedio = $dados['validade'];
        $tiporemedio = $dados['tipo'];
        $descricaoremedio = $dados['descricao'];

        echo "Código: " . $codigoremedio . "<br>" . 
            "Nome: " . $nomeremedio . "<br>" .
            "Farmácia Responsável: " . $farmrespremedio . "<br>" .
            "Validade: " . $validaderemedio . "<br>" .
            "Tipo: " . $tiporemedio . "<br>" .
            "Descrição: " . $descricaoremedio . "<br>"  ;
  
           ?>
           
           <a href="excluirmedicamento.php?id=<?php $nomeremedio?>">Excluir</a><br><br>
           <a href="alterardadosmedicamento.php?id=<?php $nomeremedio?>">Alterar</a><br><br>
<?php
    }

?>

<a href="formMedicamento.php">Cadastro de Medicamentos</a>