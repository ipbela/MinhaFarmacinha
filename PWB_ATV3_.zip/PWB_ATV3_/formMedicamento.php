<?php
    include("protect.php");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastrostyle.css">

    <title>Cadastro Remédio</title>
</head>
<body>

    <div id="form">
        <form action="cadastroMedicamento.php" method="POST">

        <h1>Cadastrar Medicamentos</h1>

    <!-- Código, nome do medicamento, farmácia responsável, data de validade, tipo, descrição e foto -->

    <label for="name">Código</label>
    <div class="input">
        <input id="codigo" name="codigo" placeholder="Insira o código do medicamento" type="text">
    </div>

    <label for="name">Nome</label>
    <div class="input">
        <input id="name" name="nome" placeholder="Insira o nome do medicamento" type="text">
    </div>

    <label for="farmresp">Farmácia Responsável</label>
    <div class="input">
        <input id="farm" name="farmresp" placeholder="Insira a farmácia responsável" type="text">
    </div>

    <label for="validade">Data de Validade</label>
    <div class="input">
        <input id="validade" name="validade" placeholder="Insira a data de validade" type="date">
    </div>
    
    <label for="tipo">Tipo</label>
    <div class="input">
        <input id="tipo" name="tipo" placeholder="Insira o tipo" type="text">
    </div>

    <label for="descricao">Descrição</label>
    <div class="input">
        <input id="descricao" name="descricao" placeholder="Insira a descrição" type="text">
    </div>

    <label for="foto">Foto do Medicamento</label>
    <div class="input">
        <input id="foto" name="foto" type="file">
    </div>

    <div id="btn">
        <button type="submit">Cadastrar</button>
    </div>

    <div id="btn">
        <a href="menu.php">Voltar Ao Menu</a>
    </div>

    </form>
    </div>
    
</body>
</html>