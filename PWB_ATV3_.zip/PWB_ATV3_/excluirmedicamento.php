<?php
	$conexao=mysqli_connect("localhost","root","","cadastro");
	if (!isset($_SESSION))
		session_start();
	$usuariologado=$_SESSION['email'];
        $buscarmedicamentoexcluir = mysqli_query($conexao,"SELECT nome FROM remedios WHERE email='$usuariologado'"); 
?>

<form method="POST">
   <select name="excluirmedicamento">
   <?php while($ver=mysqli_fetch_array($buscarmedicamentoexcluir)){
	echo "<option value='$ver[0]'>$ver[0]</option>";
   }?></select>
   <input type="submit" value="Buscar">

<?php
    if($_POST){
        $selecionado=$_POST['excluirmedicamento'];
        $imprimir = mysqli_query($conexao,"SELECT * FROM remedios WHERE email='$usuariologado' and nome='$selecionado'");
        while($num_rows = mysqli_fetch_array($imprimir)){
            echo "<p>Nome..............: ",$num_rows['nome'];
            echo "<p>Farmácia Responsável............: ",$num_rows['farmresp'];
            echo "<p>Validade...: ",$num_rows['validade'];
            echo "<p>Tipo..........: ",$num_rows['tipo'];
            echo "<p>Descrição............: ",$num_rows['descricao'];
         }
         echo "<p><b>Confirma exclusão? </b>"?>
         <form name="form2" method="POST"> 
             <input type="submit" name="confirma" value="Sim">
	 </form>
         <?php
	    if(isset($_POST['confirma'])){
  		$confirmaexcluir=mysqli_query($conexao,"DELETE FROM remedios WHERE email='$usuariologado' and nome='$selecionado'");    
                echo '<script language="JavaScript">alert("Remédio excluído!")</script>';
		?><meta http-equiv="refresh" content="0;url=menu.php"><?php
            }
        }  
?>