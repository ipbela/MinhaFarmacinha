<?php

	$telefone = $_POST['telefone'];
	$senha = $_POST['senha'];
	$nome  = $_POST['nome'];
	$email = $_POST['email'];
	$foto = $_POST['foto'];
	$erro = 0;

	if (strlen($telefone)<8){ 
		echo "O telefone deve possuir no mínimo 8 caracteres.<br>";
		$erro=1;
	}

	if (strlen($senha)<5){ 
		echo "A senha deve possuir no mínimo 5 caracteres.<br>";
		$erro=1;
	}

	if ($nome == $senha){
		echo "O nome e a senha devem ser diferentes.<br>"; 
		$erro=1; 
	}

	if (empty($nome)){
		echo "Favor digitar seu nome corretamente.<br>";
		$erro=1;
	}

	if (strlen($email)<8 || strstr($email, '@')==FALSE){
		echo "Favor digitar seu e-mail corretamente.<br>";
		$erro=1;
	}

	if ($erro==0){ 

	include "conexao_mysql.php";
	
	$criptografando = base64_encode ($senha);
	
	$query = mysqli_query($conexao, "INSERT INTO usuario(telefone,senha,nome,email,foto) VALUES ('$telefone','$criptografando','$nome','$email','$foto')");
	echo '<script language="JavaScript" charset="utf-8">alert("Usuário Cadastrado com Sucesso!!!")</script>';

	echo "Todos os dados foram digitados corretamente!";

	echo "<p><a href=formulariostyle.html>Login</a>";

	}

	else {
		echo "Houveram erros na digitação dos dados";
	}
    
?>
