<?php
	$conexao = mysqli_connect("localhost", "root", "", "cadastro");
	if (!$conexao) {
	echo "Houve erro na conexão com o banco de dados!";
	 exit;
	 }
?>